If you add this to fivem server, files are ready for fivem and just drag and drop them from the fivem folder to your eup_steam or whatever.

If you add this to singleplayer, Drag all those files (not the folders) - 
*SHIRT* Drag all the shirt files to: mp_m_freemode_01_mp_m_heist3 from the singleplayer folder.
*HAT* Drag all the hat files to: mp_m_freemode_01_p or where ever you want if you want to replace another hat!

https://discord.me/polarmods
https://discord.io/polarmods
https://dsc.gg/polarmods

DO NOT REPOST OR STEAL ANY FILES OR CLAIM AS YOURS!


This is free product if you wanna support me: https://paypal.me/ipsudelol